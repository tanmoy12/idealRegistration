module.exports = {
  dbUrl:
    "mongodb://NDCEnglishCarnival:ndc1234@ds159164.mlab.com:59164/ndc-englishcarnival",
  secret: "ndcenglishcarnival"
};
